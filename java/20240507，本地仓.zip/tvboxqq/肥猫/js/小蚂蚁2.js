var rule = {
    模板: '采集1',
    title: '小蚂蚁资源2',
    host: 'http://159.75.155.189:1133',
    // homeTid: '13',
    tab_rename:{'NBY':'公众号：肥猫宝贝'},
    cate_exclude: '连续剧|动作片|喜剧片|爱情片|科幻片|恐怖片|剧情片|战争片',
    parse_url: 'http://103.233.255.142:1133/?url=',
}